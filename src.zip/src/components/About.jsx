import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Target, Eye, Lightbulb, Users, Award, ShieldCheck, Globe, Briefcase } from 'lucide-react';

const About = () => {
    const [counts, setCounts] = useState({ projects: 0, clients: 0, years: 0 });

    useEffect(() => {
        let currentProjects = 0;
        let currentClients = 0;
        let currentYears = 0;

        const targetProjects = 500;
        const targetClients = 150;
        const targetYears = 12; // 2012 to ~2024/2026

        const interval = setInterval(() => {
            currentProjects += 5;
            currentClients += 2;
            currentYears += 1;

            if (currentProjects > targetProjects) currentProjects = targetProjects;
            if (currentClients > targetClients) currentClients = targetClients;
            if (currentYears > targetYears) currentYears = targetYears;

            setCounts({
                projects: currentProjects,
                clients: currentClients,
                years: currentYears
            });

            if (currentProjects === targetProjects && currentClients === targetClients && currentYears === targetYears) {
                clearInterval(interval);
            }
        }, 20);

        return () => clearInterval(interval);
    }, []);

    const coreValues = [
        {
            title: "Creativity with Insight",
            desc: "We’re creative and passionate, always pushing the envelope to deliver impactful, smart solutions.",
            icon: Lightbulb
        },
        {
            title: "Client Success as Our Priority",
            desc: "Our clients’ success is our own. We only succeed when they do, so we invest ourselves in understanding each client's business deeply.",
            icon: Users
        },
        {
            title: "Commitment to Quality",
            desc: "We stay updated with the latest industry trends to provide the best solutions. Our commitment is ingrained in our corporate culture.",
            icon: Award
        }
    ];

    const whyChooseUs = [
        {
            title: "Proven Expertise in Brand Engagement",
            desc: "Years of experience in B2B services and event management.",
            icon: Briefcase
        },
        {
            title: "End-to-End Solutions",
            desc: "We manage every step, from initial consultations to project delivery.",
            icon: ShieldCheck
        },
        {
            title: "Strategic Market Reach",
            desc: "An established network that enables global expansion with confidence.",
            icon: Globe
        }
    ];

    return (
        <section id="about" className="py-24 bg-white relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-brand-primary/5 rounded-full blur-3xl translate-x-1/3 -translate-y-1/3"></div>
            <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-brand-secondary/5 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2"></div>

            <div className="container mx-auto px-6 max-w-7xl relative z-10">

                {/* 1. Who We Are */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
                    <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6 }}
                    >
                        <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">Who We <span className="text-brand-primary">Are</span></h2>
                        <div className="text-lg text-slate-600 space-y-4 leading-relaxed">
                            <p>
                                Founded in 2012 and headquartered in the cultural hub of Thrissur, Kerala, <strong>B2P International</strong> is a premier B2B service provider managed by a team of young, dynamic professionals. For over a decade, we have dedicated ourselves to streamlining international trade and professional networking, serving as a vital link between global enterprises and their target audiences.
                            </p>
                        </div>

                        <div className="grid grid-cols-3 gap-8 pt-10 mt-10 border-t border-slate-100">
                            <div>
                                <h3 className="text-4xl font-black text-brand-primary mb-1">{counts.projects}+</h3>
                                <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Projects</p>
                            </div>
                            <div>
                                <h3 className="text-4xl font-black text-brand-primary mb-1">{counts.clients}+</h3>
                                <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Clients</p>
                            </div>
                            <div>
                                <h3 className="text-4xl font-black text-brand-primary mb-1">{counts.years}+</h3>
                                <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Years Exp.</p>
                            </div>
                        </div>
                    </motion.div>

                    <motion.div
                        initial={{ opacity: 0, x: 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.6, delay: 0.2 }}
                        className="relative h-[500px] rounded-3xl overflow-hidden shadow-2xl group"
                    >
                        {/* Placeholder for an office or team image */}
                        <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/80 to-brand-secondary/80 mix-blend-multiply z-10 transition-opacity duration-500 group-hover:opacity-70"></div>
                        <img
                            src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop"
                            alt="B2P Team Collaboration"
                            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 z-20 flex items-center justify-center p-10 text-center">
                            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl">
                                <h3 className="text-3xl font-bold text-white mb-2">Since 2012</h3>
                                <p className="text-white/80 font-medium tracking-wide">Connecting Businesses Globally</p>
                            </div>
                        </div>
                    </motion.div>
                </div>

                {/* 2. Mission & Vision */}
                <div className="mb-32 relative">
                    {/* Ambient Glowing Orbs Background */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] opacity-40 pointer-events-none z-0 hidden md:block">
                        <div className="absolute top-0 left-10 w-80 h-80 bg-brand-primary rounded-full mix-blend-multiply filter blur-[100px] opacity-70 animate-pulse"></div>
                        <div className="absolute top-0 right-10 w-80 h-80 bg-brand-secondary rounded-full mix-blend-multiply filter blur-[100px] opacity-70 animate-pulse delay-700"></div>
                        <div className="absolute -bottom-10 left-1/2 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-[100px] opacity-70 animate-pulse delay-1000"></div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 relative z-10 mx-auto">

                        {/* Mission - Large Glassmorphic Bento Card */}
                        <motion.div
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.7, type: "spring", stiffness: 100 }}
                            className="md:col-span-8 group"
                        >
                            <div className="h-full bg-white/80 backdrop-blur-3xl rounded-[2.5rem] p-10 md:p-14 border border-white shadow-[0_8px_30px_rgb(0,0,0,0.06)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.12)] transition-all duration-500 relative overflow-hidden">
                                {/* Decor */}
                                <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-brand-primary/10 to-transparent rounded-bl-full opacity-50 group-hover:scale-125 transition-transform duration-700"></div>

                                <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-slate-50 border border-slate-100 mb-8 shadow-sm">
                                    <div className="w-2.5 h-2.5 rounded-full bg-brand-primary animate-pulse"></div>
                                    <span className="text-xs font-bold tracking-widest text-slate-800 uppercase">Connecting Global Markets</span>
                                </div>

                                <h3 className="text-5xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight leading-[1.1]">
                                    Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-secondary">Mission</span>
                                </h3>

                                <p className="text-slate-600 leading-relaxed text-lg md:text-xl font-medium max-w-2xl mt-8 border-l-2 border-brand-primary/30 pl-6">
                                    To bridge businesses with the people they serve. In an increasingly fragmented global economy, we act as a strategic catalyst—linking markets through a holistic approach that anticipates the evolving needs of the modern customer.
                                </p>
                            </div>
                        </motion.div>

                        {/* Vision - Tall Dark Bento Card */}
                        <motion.div
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.7, delay: 0.15, type: "spring", stiffness: 100 }}
                            className="md:col-span-4 group"
                        >
                            <div className="h-full bg-slate-900 rounded-[2.5rem] p-10 md:p-12 border border-slate-800 shadow-[0_8px_30px_rgb(0,0,0,0.15)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.25)] transition-all duration-500 relative flex flex-col justify-between overflow-hidden">
                                {/* Mesh Gradient Background */}
                                <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/30 via-slate-900 to-brand-secondary/30 opacity-40 group-hover:opacity-70 transition-opacity duration-700"></div>

                                <div className="relative z-10 mb-8">
                                    <div className="w-16 h-16 bg-white/10 backdrop-blur-xl rounded-2xl flex items-center justify-center border border-white/20 mb-10 text-brand-primary shadow-[0_0_15px_rgba(255,255,255,0.1)] group-hover:-translate-y-2 transition-transform duration-500">
                                        <Eye size={32} />
                                    </div>

                                    <h3 className="text-4xl font-black text-white mb-6 tracking-tight">
                                        Our Vision
                                    </h3>
                                </div>

                                <p className="text-slate-300 leading-relaxed text-lg relative z-10 font-light mt-auto">
                                    "To become a trusted global leader in B2B services, where creativity, insight, and passion come together to build brands and drive success."
                                </p>

                                {/* Decorative Dots */}
                                <div className="absolute bottom-10 right-10 flex gap-1.5 z-10">
                                    <div className="w-2 h-2 rounded-full bg-white/20 group-hover:bg-white/40 transition-colors"></div>
                                    <div className="w-2 h-2 rounded-full bg-white/40 group-hover:bg-white/60 transition-colors"></div>
                                    <div className="w-2 h-2 rounded-full bg-brand-primary group-hover:scale-150 transition-transform"></div>
                                </div>
                            </div>
                        </motion.div>

                    </div>
                </div>

                {/* 3. Core Values - New Bold Design */}
                <div className="mb-32 relative pt-10">
                    <div className="text-center mb-16 max-w-2xl mx-auto">
                        <motion.h2
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="text-4xl md:text-5xl font-black text-slate-900 uppercase tracking-tighter"
                        >
                            The <span className="text-brand-primary">B2P Way.</span>
                        </motion.h2>
                        <p className="mt-4 text-slate-600 font-medium">Built on principles that drive real results.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-10 relative z-10 px-4 md:px-0 max-w-5xl mx-auto">
                        {coreValues.map((value, idx) => {
                            // Assign unique bold colors to each card
                            const bgColors = [
                                "bg-[#FFEFD5] border-[#FFB649]",
                                "bg-[#E6F4FF] border-[#66B2FF]",
                                "bg-[#F3E8FF] border-[#C084FC]"
                            ];
                            const shadowColors = [
                                "hover:shadow-[-8px_8px_0_0_#FFB649]",
                                "hover:shadow-[-8px_8px_0_0_#66B2FF]",
                                "hover:shadow-[-8px_8px_0_0_#C084FC]"
                            ];
                            const iconColors = [
                                "text-[#F59E0B]",
                                "text-[#3B82F6]",
                                "text-[#8B5CF6]"
                            ];

                            return (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: idx * 0.1, duration: 0.4 }}
                                    className={`group rounded-3xl p-8 md:p-10 border-2 ${bgColors[idx]} ${shadowColors[idx]} shadow-[-4px_4px_0_0_rgba(15,23,42,0.1)] hover:-translate-y-2 hover:translate-x-2 transition-all duration-300 flex flex-col relative overflow-hidden`}
                                >
                                    <div className="absolute top-0 right-0 p-4 opacity-10 transform translate-x-1/4 -translate-y-1/4 group-hover:scale-150 transition-transform duration-700">
                                        {React.createElement(value.icon, { size: 120 })}
                                    </div>

                                    <div className={`w-14 h-14 bg-white rounded-xl flex items-center justify-center mb-8 border-2 ${bgColors[idx].split(' ')[1]} shadow-sm z-10`}>
                                        {React.createElement(value.icon, { size: 28, className: iconColors[idx] })}
                                    </div>

                                    <h4 className="text-2xl font-black text-slate-900 mb-4 tracking-tight z-10">{value.title}</h4>

                                    <p className="text-slate-700 leading-snug font-medium z-10">{value.desc}</p>
                                </motion.div>
                            );
                        })}
                    </div>
                </div>

                {/* 4. Why Choose Us */}
                <div>
                    <div className="text-center mb-16 max-w-2xl mx-auto">
                        <motion.h2
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="text-3xl md:text-4xl font-black text-slate-900"
                        >
                            Why <span className="text-brand-secondary">Choose Us?</span>
                        </motion.h2>
                    </div>

                    <div className="bg-slate-900 rounded-[3rem] p-10 md:p-16 relative overflow-hidden shadow-2xl">
                        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
                            {whyChooseUs.map((reason, idx) => (
                                <motion.div
                                    key={idx}
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: 0.2 + (idx * 0.1), duration: 0.5 }}
                                    className="text-center md:text-left"
                                >
                                    <div className="flex justify-center md:justify-start mb-6">
                                        <div className="w-14 h-14 bg-white/10 rounded-xl flex items-center justify-center text-white border border-white/20">
                                            {React.createElement(reason.icon, { size: 28 })}
                                        </div>
                                    </div>
                                    <h4 className="text-xl font-bold text-white mb-3">{reason.title}</h4>
                                    <p className="text-slate-400 leading-relaxed">{reason.desc}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>

            </div>
        </section>
    );
};

export default About;
