import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Truck, BarChart, Rocket } from 'lucide-react';

const servicesSlider = [
    {
        id: 1,
        title: "LED Mobile",
        titleHighlight: "Advertising",
        desc: "High-impact mobile physical reach. We take your brand directly to the streets, ensuring maximum visibility across cities with our dynamic LED displays.",
        icon: Truck
    },
    {
        id: 2,
        title: "AI-Driven Growth",
        titleHighlight: "Solutions",
        desc: "Precision marketing through data and automation. We harness artificial intelligence for advanced social intelligence, SEO, and paid strategies that convert.",
        icon: BarChart
    },
    {
        id: 3,
        title: "Global Marketing",
        titleHighlight: "Campaigns",
        desc: "Custom-tailored campaigns designed for scale and brand elevation. We cut through the noise to deliver unparalleled ROI and global recognition.",
        icon: Rocket
    }
];

const Hero = () => {
    const [currentSlide, setCurrentSlide] = useState(0);

    // Auto-rotate
    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentSlide((prev) => (prev + 1) % servicesSlider.length);
        }, 5000);
        return () => clearInterval(timer);
    }, []);

    return (
        <section
            id="home"
            className="relative h-screen flex items-center justify-center overflow-hidden bg-slate-50"
        >
            {/* Background Gradient */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,_rgba(37,99,235,0.15)_0%,_transparent_50%),radial-gradient(circle_at_30%_70%,_rgba(124,58,237,0.15)_0%,_transparent_50%)] z-0 pointer-events-none"></div>

            <div className="container mx-auto px-4 sm:px-6 relative z-10 w-full max-w-7xl">
                <div className="flex items-center justify-center w-full">
                    <div className="flex-1 w-full mx-auto relative h-[500px] flex items-center justify-center px-2 sm:px-8">
                        <AnimatePresence mode="wait">
                            <motion.div
                                key={currentSlide}
                                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.95, y: -20 }}
                                transition={{ duration: 0.5, ease: "easeInOut" }}
                                className="w-full max-w-3xl flex flex-col items-center text-center backdrop-blur-sm bg-white/30 p-6 sm:p-10 rounded-[3rem] border border-white/40 shadow-2xl relative"
                            >
                                <div className="mb-6 p-4 sm:p-5 bg-white rounded-2xl shadow-xl shadow-slate-200/50 inline-flex items-center justify-center transform hover:scale-105 transition-transform duration-300">
                                    {React.createElement(servicesSlider[currentSlide].icon, { size: 48, className: "text-brand-primary" })}
                                </div>
                                <h1 className="text-4xl sm:text-5xl md:text-6xl font-black mb-6 tracking-tight text-slate-900 leading-tight">
                                    {servicesSlider[currentSlide].title} <br className="hidden md:block" />
                                    <span className="text-gradient">{servicesSlider[currentSlide].titleHighlight}</span>
                                </h1>
                                <p className="text-base sm:text-lg md:text-xl text-slate-700 mb-10 max-w-2xl mx-auto font-medium">
                                    {servicesSlider[currentSlide].desc}
                                </p>

                                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
                                    <a
                                        href="#services"
                                        className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-gradient-to-r from-brand-primary to-brand-secondary text-white font-semibold hover:scale-105 hover:shadow-xl hover:shadow-brand-primary/30 transition-all duration-300"
                                    >
                                        Explore Scope
                                    </a>
                                    <a
                                        href="#contact"
                                        className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-white border border-slate-200 text-slate-900 font-semibold hover:border-brand-primary hover:bg-slate-50 hover:scale-105 transition-all duration-300 shadow-sm"
                                    >
                                        Get in Touch
                                    </a>
                                </div>
                            </motion.div>
                        </AnimatePresence>
                    </div>
                </div>
            </div>

            {/* Scroll indicator */}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1, duration: 1 }}
                className="absolute bottom-6 left-1/2 -translate-x-1/2"
            >
                <a href="#trust" aria-label="Scroll down" className="flex justify-center items-start w-8 h-12 border-2 border-slate-400/50 rounded-full p-1 cursor-pointer hover:border-brand-primary transition-colors">
                    <motion.div
                        animate={{ y: [0, 15, 0], opacity: [1, 0, 1] }}
                        transition={{ repeat: Infinity, duration: 1.5 }}
                        className="w-1.5 h-3 bg-brand-primary rounded-full"
                    />
                </a>
            </motion.div>
        </section>
    );
};

export default Hero;
